import createError from 'http-errors';
import jwt from 'jsonwebtoken';
import { config } from '../config/index.js';

export function authenticate(req, _res, next) {
  const header = req.headers['authorization'];
  if (!header) return next(createError(401, 'Missing Authorization header'));
  const [type, token] = header.split(' ');
  if (type !== 'Bearer' || !token) return next(createError(401, 'Invalid Authorization header'));
  try {
    const payload = jwt.verify(token, config.jwt.accessSecret);
    req.user = payload;
    if (req.user.disabled) return next(createError(403, 'Account disabled'));
    next();
  } catch (err) {
    next(createError(401, 'Invalid or expired token'));
  }
}

export function authorize(...roles) {
  return (req, _res, next) => {
    if (!req.user) return next(createError(401, 'Unauthenticated'));
    if (!roles.includes(req.user.role)) return next(createError(403, 'Forbidden'));
    next();
  };
}
