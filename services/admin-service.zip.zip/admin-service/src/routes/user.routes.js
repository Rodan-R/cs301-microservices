import { Router } from 'express';
import { authenticate, authorize } from '../middleware/auth.js';
import * as ctrl from '../controllers/user.controller.js';

const router = Router();

router.use(authenticate, authorize('admin'));
router.post('/', ctrl.create);
router.get('/', ctrl.list);
router.get('/:id', ctrl.get);
router.put('/:id', ctrl.update);
router.patch('/:id/delete', ctrl.softDelete);

export default router;
