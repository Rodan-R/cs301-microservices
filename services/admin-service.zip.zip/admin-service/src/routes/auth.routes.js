import { Router } from 'express';
import { login, refresh, resetPassword } from '../controllers/auth.controller.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = Router();

router.post('/login', login);
router.post('/refresh', refresh);
router.post('/reset-password', authenticate, authorize('admin'), resetPassword);

export default router;
