import createError from 'http-errors';
import { createUser, listUsers, getUser, updateUser, softDeleteUser } from '../services/user.service.js';
import { registerSchema, updateUserSchema } from '../utils/validators.js';

export async function create(req, res, next) {
  try {
    const { value, error } = registerSchema.validate(req.body);
    if (error) throw createError(400, error.message);
    const user = await createUser(value);
    res.status(201).json(user);
  } catch (err) {
    next(err);
  }
}

export async function list(_req, res, next) {
  try {
    const users = await listUsers();
    res.json(users);
  } catch (err) {
    next(err);
  }
}

export async function get(req, res, next) {
  try {
    const user = await getUser(req.params.id);
    res.json(user);
  } catch (err) {
    next(err);
  }
}

export async function update(req, res, next) {
  try {
    const { value, error } = updateUserSchema.validate(req.body);
    if (error) throw createError(400, error.message);
    const user = await updateUser(req.params.id, value);
    res.json(user);
  } catch (err) {
    next(err);
  }
}

export async function softDelete(req, res, next) {
  try {
    const { reason } = req.body;
    const user = await softDeleteUser(req.params.id, reason);
    res.json({ message: 'User soft-deleted', user });
  } catch (err) {
    next(err);
  }
}
