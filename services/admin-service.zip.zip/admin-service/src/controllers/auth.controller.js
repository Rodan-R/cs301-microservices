import createError from 'http-errors';
import bcrypt from 'bcryptjs';
import { prisma } from '../db/prisma.js';
import { signAccessToken, signRefreshToken, verifyRefreshToken } from '../services/token.service.js';
import { loginSchema, resetPasswordSchema } from '../utils/validators.js';

export async function login(req, res, next) {
  try {
    const { value, error } = loginSchema.validate(req.body);
    if (error) throw createError(400, error.message);

    const user = await prisma.user.findUnique({ where: { email: value.email } });
    if (!user) throw createError(401, 'Invalid credentials');
    if (user.disabled) throw createError(403, 'Account disabled');

    const ok = await bcrypt.compare(value.password, user.passwordHash);
    if (!ok) throw createError(401, 'Invalid credentials');

    const payload = { sub: user.id, role: user.role, email: user.email, disabled: user.disabled };
    const accessToken = signAccessToken(payload);
    const refreshToken = signRefreshToken({ sub: user.id });

    const { passwordHash: _ph, ...safe } = user;
    res.json({ user: safe, accessToken, refreshToken });
  } catch (err) {
    next(err);
  }
}

export async function refresh(req, res, next) {
  try {
    const { token } = req.body || {};
    if (!token) throw createError(400, 'Missing refresh token');
    const decoded = verifyRefreshToken(token);
    const user = await prisma.user.findUnique({ where: { id: decoded.sub } });
    if (!user) throw createError(401, 'Invalid token subject');
    if (user.disabled) throw createError(403, 'Account disabled');
    const accessToken = signAccessToken({ sub: user.id, role: user.role, email: user.email, disabled: user.disabled });
    res.json({ accessToken });
  } catch (err) {
    next(err);
  }
}

export async function resetPassword(req, res, next) {
  try {
    const { value, error } = resetPasswordSchema.validate(req.body);
    if (error) throw createError(400, error.message);

    const user = await prisma.user.findUnique({ where: { email: value.email } });
    if (!user) throw createError(404, 'User not found');

    const passwordHash = await bcrypt.hash(value.newPassword, 10);
    await prisma.user.update({ where: { id: user.id }, data: { passwordHash } });

    res.json({ message: 'Password reset successful' });
  } catch (err) {
    next(err);
  }
}
