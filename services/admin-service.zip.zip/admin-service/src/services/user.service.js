import createError from 'http-errors';
import bcrypt from 'bcryptjs';
import { prisma } from '../db/prisma.js';

export async function ensureRootAdmin({ email, password }) {
  const existing = await prisma.user.findUnique({ where: { email } });
  if (!existing) {
    const passwordHash = await bcrypt.hash(password, 10);
    await prisma.user.create({
      data: {
        firstName: 'Root',
        lastName: 'Admin',
        email,
        role: 'admin',
        passwordHash,
        disabled: false
      }
    });
    return true;
  }
  return false;
}

export async function createUser({ firstName, lastName, email, role, password }) {
  const exists = await prisma.user.findUnique({ where: { email } });
  if (exists) throw createError(409, 'Email already in use');
  const passwordHash = await bcrypt.hash(password, 10);
  const user = await prisma.user.create({
    data: { firstName, lastName, email, role, passwordHash }
  });
  const { passwordHash: _ph, ...safe } = user;
  return safe;
}

export async function updateUser(id, updates) {
  const allowed = ['firstName', 'lastName', 'role'];
  const filtered = Object.fromEntries(Object.entries(updates).filter(([k]) => allowed.includes(k)));
  try {
    const user = await prisma.user.update({ where: { id }, data: filtered });
    const { passwordHash: _ph, ...safe } = user;
    return safe;
  } catch {
    throw createError(404, 'User not found');
  }
}

export async function softDeleteUser(id, reason = 'No reason provided') {
  try {
    const user = await prisma.user.update({
      where: { id },
      data: { deletedAt: new Date(), deletedReason: reason }
    });
    const { passwordHash: _ph, ...safe } = user;
    return safe;
  } catch {
    throw createError(404, 'User not found');
  }
}

export async function getUser(id) {
  const user = await prisma.user.findUnique({ where: { id } });
  if (!user || user.deletedAt) throw createError(404, 'User not found');
  const { passwordHash: _ph, ...safe } = user;
  return safe;
}

export async function listUsers() {
  const users = await prisma.user.findMany({
    where: { deletedAt: null },
    orderBy: { createdAt: 'desc' }
  });
  return users.map(({ passwordHash, ...safe }) => safe);
}
